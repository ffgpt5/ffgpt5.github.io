# service.py — FILTERED: zamyka tylko okdialog i notification, nie rusza innych
import time
import threading
import xbmc

MON = xbmc.Monitor()
PLAYER = xbmc.Player()

def _sweep(seconds=6.0, interval=0.12):
    t_end = time.time() + seconds
    while time.time() < t_end and not MON.abortRequested():
        try:
            pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            pl.clear()
        except Exception:
            pass
        try: xbmc.executebuiltin('PlayerControl(RepeatOff)')
        except Exception: pass
        # zamykaj tylko typowe okna błędu odtwarzania
        try: xbmc.executebuiltin('Dialog.Close(okdialog)')
        except Exception: pass
        try: xbmc.executebuiltin('Dialog.Close(notification)')
        except Exception: pass
        time.sleep(interval)

class _Guard(xbmc.Player):
    def onPlayBackStopped(self): threading.Thread(target=_sweep, daemon=True).start()
    def onPlayBackEnded(self):   threading.Thread(target=_sweep, daemon=True).start()

_G = _Guard()

# Pętla strażnika: gdy nie odtwarzamy, domykaj okdialog/notification co 120ms
while not MON.abortRequested():
    if not PLAYER.isPlaying():
        try: xbmc.executebuiltin('Dialog.Close(okdialog)')
        except Exception: pass
        try: xbmc.executebuiltin('Dialog.Close(notification)')
        except Exception: pass
    if MON.waitForAbort(0.12):
        break